<?php
if (!defined('ABSPATH')) exit;

class WWN_Order_Hooks {
    private $opt;
    private $template_name = 'ratinia';
    private $template_lang = 'en'; // Template language code

    public function __construct() {
        $this->opt = get_option(WWN_OPTION_KEY, []);

        // Template name from brand
        $this->template_name = strtolower($this->opt['brand_name'] ?? 'ratinia');

        // Safety: ensure DB handler is loaded
        if (!class_exists('WWN_DB_Handler')) {
            error_log('WWN ERROR: WWN_DB_Handler not loaded. Check require_once in main plugin file.');
            return; // hard exit: prevents fatal on hooks
        }

        // Store/Update every status change
        add_action('woocommerce_order_status_changed', [$this, 'on_order_status_changed'], 10, 4);

        // Send on completed (guarded against duplicates)
        add_action('woocommerce_order_status_completed', [$this, 'on_order_completed'], 10, 1);
        // If you find duplicate sends, comment the next hook:
        // add_action('woocommerce_thankyou', [$this, 'on_order_completed'], 10, 1);

        error_log("WWN DEBUG: Order hooks registered");
    }

    /**
     * Save or update record for ANY status transition
     */
    public function on_order_status_changed($order_id, $old_status, $new_status, $order) {
        if (!class_exists('WWN_DB_Handler')) return;

        // Grab billing phone from order as source, sanitize before saving
        $raw_phone = method_exists($order, 'get_billing_phone') ? $order->get_billing_phone() : '';
        $phone     = WWN_DB_Handler::sanitize_phone($raw_phone, '91');

        // Upsert into our custom table
        WWN_DB_Handler::upsert_order($order_id, $new_status, $phone, '');

        error_log("WWN DEBUG: Order {$order_id} {$old_status} -> {$new_status} saved (phone: {$phone})");
    }

    /**
     * Send WhatsApp message when order is completed (only once)
     */
    public function on_order_completed($order_id) {
        if (!class_exists('WWN_DB_Handler')) return;

        $order = wc_get_order($order_id);
        if (!$order) {
            error_log("WWN DEBUG: Order not found for ID {$order_id}");
            return;
        }

        // Duplicate-send guard
        if (get_post_meta($order_id, '_wwn_completed_sent', true)) {
            error_log("WWN DEBUG: Skipping duplicate send for Order {$order_id}");
            return;
        }

        // Phone must come from our table
        $customer_phone = WWN_DB_Handler::get_phone_by_order($order_id);

        // Optional fallback to billing phone (if table empty). Uncomment if needed.
        /*
        if (!$customer_phone) {
            $customer_phone = WWN_DB_Handler::sanitize_phone($order->get_billing_phone(), '91');
            if ($customer_phone) {
                WWN_DB_Handler::update_phone($order_id, $customer_phone);
                error_log("WWN DEBUG: Fallback phone saved for Order {$order_id}");
            }
        }
        */

        if (!$customer_phone) {
            error_log("WWN DEBUG: No phone in table for Order {$order_id}; aborting send.");
            return;
        }

        // Build product image for header (optional)
        $product_image_url = '';
        $items = $order->get_items();
        if (!empty($items)) {
            $first_item = reset($items);
            $product_id = $first_item->get_product_id();
            $img_id     = get_post_thumbnail_id($product_id);
            if ($img_id) $product_image_url = wp_get_attachment_url($img_id);
        }
        if (!$product_image_url) {
            $product_image_url = "https://yourdomain.com/default-image.jpg";
        }

        // WhatsApp API creds
        $phone_number_id = $this->opt['phone_number_id'] ?? '';
        $access_token    = $this->opt['access_token'] ?? '';

        if (!$phone_number_id || !$access_token) {
            error_log("WWN DEBUG: Missing WhatsApp API credentials.");
            return;
        }

        $url  = "https://graph.facebook.com/v22.0/{$phone_number_id}/messages";

        $payload = array(
            "messaging_product" => "whatsapp",
            "to"                => $customer_phone,
            "type"              => "template",
            "template"          => array(
                "name"     => $this->template_name,
                "language" => array("code" => $this->template_lang),
                "components" => array(
                    array(
                        "type"       => "header",
                        "parameters" => array(
                            array(
                                "type"  => "image",
                                "image" => array("link" => $product_image_url)
                            )
                        )
                    )
                )
            )
        );

        // Send
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Authorization: Bearer {$access_token}",
            "Content-Type: application/json"
        ));
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, wp_json_encode($payload));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            $err = curl_error($ch);
            error_log("WWN DEBUG: cURL Error - {$err}");
            WWN_DB_Handler::update_status($order_id, 'failed');
        } else {
            error_log("WWN DEBUG: WhatsApp API Response - " . $response);
            WWN_DB_Handler::update_status($order_id, 'completed');

            // Mark sent to avoid duplicates
            update_post_meta($order_id, '_wwn_completed_sent', 1);
        }

        curl_close($ch);
    }
}
